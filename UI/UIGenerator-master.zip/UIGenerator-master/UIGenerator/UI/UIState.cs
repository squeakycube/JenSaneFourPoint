﻿namespace UIGenerator.UI
{
    public class UIState : UIElement
    {
        public UIState()
        {
            Width.Precent = 1f;
            Height.Precent = 1f;
            Recalculate();
        }
    }
}
