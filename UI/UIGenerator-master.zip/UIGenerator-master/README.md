![UIGenerator-Banner](https://user-images.githubusercontent.com/26361108/111703832-81aed280-883e-11eb-95aa-70392dc7a35f.png)

___
A tool to generate UI Code for tModLoader

This project is still not finished. See the milestone for what need to be done.
![image](https://user-images.githubusercontent.com/26361108/110858982-0b98f180-82bb-11eb-8cbd-62d6e62cbbe2.png)

# [How To Install](https://github.com/NotLe0n/UIGenerator/wiki/How-To-Install)

# [How To Use](https://github.com/NotLe0n/UIGenerator/wiki/How-To-Use)
