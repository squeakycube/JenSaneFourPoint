using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using static Terraria.ModLoader.ModContent;

namespace JenSaneFourPoint
{
	public class ExamplePlayer : ModPlayer
	{
		public bool examplePet;
		public bool exampleLightPet;
		
		public bool tmmcPet;

        public bool damageReduction;
        public bool CloakAccessoryEquipped;

        public static int KillCount { get; set; } = 0;
        public int RefKillCount;

        //public int MinionFruits;


        public bool PreHurt(bool pvp, bool quiet, ref int damage, ref int hitDirection, ref bool crit, ref bool customDamage, ref bool playSound, ref bool genGore, ref string deathText)
        {
            if (this.damageReduction && damage > 350)
                if (Main.rand.Next(8) == 1)
                    damage = 350;
            Player.NinjaDodge();
            damage = 0;

            return true;
        }

    }

}