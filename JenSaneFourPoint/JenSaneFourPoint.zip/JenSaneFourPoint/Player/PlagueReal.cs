using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.GameContent.Creative;
using Microsoft.Xna.Framework.Graphics;
using Terraria.ID;
using Terraria.ModLoader;
using Terraria.ModLoader.IO;
using System;
using System.Collections.Generic;
using Terraria.GameInput;
using Terraria.Utilities;
using Terraria.Localization;
using Terraria.GameContent;
using Terraria.DataStructures;
using Terraria.Map;



namespace JenSaneFourPoint
{
    public class PlagueReal : ModPlayer
    {
        // These indicate what direction is what in the timer arrays used

        public int Potency = 0;
        public int PotencyConsume = 0;
        public int PotencyMax = 1000;
        public int PotencyRegen = 1;
        public bool InHealDistance;

        public bool TeamHealAccessoryEquipped;//            TeamHealAccessoryEquipped = false;
        public bool MassMaxHealAccessoryEquipped;
        public bool CloakAccessoryEquipped; //This should be skull, change it later
        public bool MedBagEquipped; //For med supplies and sigil
        public bool PlagueSet1Equipped;
        public bool PlagueSet2Equipped;
        public bool PlagueSet3Equipped; //PlagueRegenItemEquipped
        public bool PlagueRegenItemEquipped;
        public bool PlagueRegenMoonLordEquipped;
        public bool MushroomSet1Equipped;
        public bool MushroomSet2Equipped;
        public bool MushroomSet3Equipped;
        public bool ThornAccessoryEquipped;
        public int surgicalint = 30;
        public int HPRegen = 30;
        //if (this.MedBagEquipped)
        public bool SkullHeartRegenIncrease;
        public bool LesserPlagueRegenItemEquipped;
        public bool WeDontLikeThomas;
        public bool MLPlagueSet1Equipped;
        public bool MLPlagueSet2Equipped;
        public bool MLPlagueSet3Equipped;
        public bool PlagueCause;
        public bool PlagueRegenPotion;
        public bool FreedSoul;
        public bool disfoostupidongod;
        public bool NecroMark;
        public bool Scalpel;


        public bool SpawnThomas;



        public bool healingPrefix;

        public bool InsaneMode;

        public bool TeamHeal;

        public void RemovePotency(int chance, int number)
        {
            for (int i = 0; i < number; i++)
            {
                if (Main.rand.Next(100) < (chance - PotencyConsume))
                {
                    Potency--;
                }
            }
        }

        

        public override void ProcessTriggers(TriggersSet triggersSet)
        {

        


            //if (JenSaneFourPoint.FreezeKey.JustPressed)



            // Potency -= 15;

        }


        public override void ResetEffects()
        {
            TeamHealAccessoryEquipped = false;
            InHealDistance = false;
            MassMaxHealAccessoryEquipped = false;
            CloakAccessoryEquipped = false;
            MedBagEquipped = false;
            PlagueSet1Equipped = false;
            PlagueSet2Equipped = false;
            PlagueSet3Equipped = false;
            PlagueRegenItemEquipped = false;
            PlagueRegenMoonLordEquipped = false;
            MushroomSet1Equipped = false;
            MushroomSet2Equipped = false;
            MushroomSet3Equipped = false; //ThornAccessoryEquipped
            ThornAccessoryEquipped = false;
            SkullHeartRegenIncrease = false;
            LesserPlagueRegenItemEquipped = false;
            WeDontLikeThomas = false;
            MLPlagueSet1Equipped = false;
            MLPlagueSet2Equipped = false;
            MLPlagueSet3Equipped = false;
            PlagueCause = false;
            PlagueRegenPotion = false;
            FreedSoul = false;
           // MurderedThomas = false;
            SpawnThomas = false;
            disfoostupidongod = false;
            NecroMark = false;
            Scalpel = false;
        }

        public void UpdateSkull()
        {
            //  PlagueReal p = player.GetModPlayer<PlagueReal>();

            
        }

        public void UpdateSkuHea2(Player player, bool hideVisual)
        {
                if (JenSaneFourPoint.TeamRegenVer2.Current) //SkullenHeart
            {
                if (this.MedBagEquipped)
                {
                    if (Potency >= 10)
                    {
                        //if (CloakAccessoryEquipped = true)
                        if (this.CloakAccessoryEquipped)
                        //if (this.MedBagEquipped)
                        {
                            //var player2 = Main.player[Main.myPlayer];


                            //int p = Player.FindClosest(Player.Center, 0, 0);

                            Player.controlUseItem = false;
                            Potency -= 4;
                            //       Player.lifeRegen += HPRegen;
                            Player.GetDamage(DamageClass.Generic) -= 0.75f;
                            Player.moveSpeed -= 1.0f;
               //             ExamplePlayer p = player.GetModPlayer<ExamplePlayer>();
                 //           p.DocSkull = true;
                        }
                    }
                }
            }
        }

            public Player FindClosestPlayer(float maxDetectDistance)
        {
            Player closestPlayer = null;

            // Using squared values in distance checks will let us skip square root calculations, drastically improving this method's speed.
            float sqrMaxDetectDistance = maxDetectDistance * maxDetectDistance;

            // Loop through all NPCs(max always 200)
            for (int k = 0; k < Main.maxPlayers; k++)
            {
                Player target = Main.player[k];
                // Check if NPC able to be targeted. It means that NPC is
                // 1. active (alive)
                // 2. chaseable (e.g. not a cultist archer)
                // 3. max life bigger than 5 (e.g. not a critter)
                // 4. can take damage (e.g. moonlord core after all it's parts are downed)
                // 5. hostile (!friendly)
                // 6. not immortal (e.g. not a target dummy)
                // The DistanceSquared function returns a squared distance between 2 points, skipping relatively expensive square root calculations
                float sqrDistanceToTarget = Vector2.DistanceSquared(target.Center, Player.Center);

                // Check if it is within the radius
                if (sqrDistanceToTarget < sqrMaxDetectDistance)
                {
                    sqrMaxDetectDistance = sqrDistanceToTarget;
                    closestPlayer = target;
                }
            }

            return closestPlayer;
        }

        // public NPC npc = Mod.Find<ModNPC>("Thomas").Type;

        //private static HookList HookInitialize = AddHook<Action>(p => p.Initialize);



        //                Player.AddBuff(ModContent.BuffType<Buffs.Plague>(), 600);


        public void UpdateSkuHea(Player player)
        {
            //   if (this.DocSkull)
            //   {
            //      PlagueReal p = player.GetModPlayer<PlagueReal>();

            //   var num25 = Main.myPlayer;

            // Main.player[num25].lifeRegen += p.HPRegen;
            //}

      //      ExamplePlayer p = player.GetModPlayer<ExamplePlayer>();
    //        p.DocSkull = true;
        }

        public override void PostUpdateEquips() //ThornAccessoryEquipped
        {

            if (Potency > PotencyMax) //Patch for if player has over 1000 potency it removes potency until its at 1000
            {
                    Potency -= 1;
            }

            if (JenSaneFourPoint.TeamRegenVer2.Current) //Scalpel
            {
                if (this.MedBagEquipped)
                {
                    if (Potency >= 10)
                    {
                        if (this.Scalpel)
                        {
                            Player.lifeRegen -= 60;
                            //Main.player[num25].AddBuff(ModContent.BuffType<Buffs.Plague>(), 600, true);
                            //    Player.lifeRegen += 999;

                            Player.controlUseItem = false;
                            Potency -= 6;
                            //       Player.lifeRegen += HPRegen;
                            Player.GetDamage(DamageClass.Generic) -= 1.0f;
                            Player.moveSpeed -= 1.0f;

                            var num25 = Main.myPlayer;
                            Player closestPlayer = Main.player[Player.FindClosest(Player.Center, Main.player[num25].width, Main.player[num25].height)];
                            closestPlayer.lifeRegen += 20;
                        }
                    }
                }
            }


                            if (JenSaneFourPoint.TeamRegenVer2.Current) //SkullenHeart
            {
                if (this.MedBagEquipped)
                {
                    if (Potency >= 10)
                    {
                        //if (CloakAccessoryEquipped = true)
                        if (this.CloakAccessoryEquipped)
                        //if (this.MedBagEquipped)
                        {
                          //  Main.NewText($"MR. ELECTRIC PUT THIS *fella* IN THE PENIS EXPLOSION CHAMBER.");


                         //   Player.AddBuff(ModContent.BuffType<Buffs.Plague>(), 600, true);
                            Player.lifeRegen += HPRegen;
                            //Main.player[num25].AddBuff(ModContent.BuffType<Buffs.Plague>(), 600, true);
                            //    Player.lifeRegen += 999;

                            Player.controlUseItem = false;
                            Potency -= 4;
                            //       Player.lifeRegen += HPRegen;
                            Player.GetDamage(DamageClass.Generic) -= 0.75f;
                            Player.moveSpeed -= 1.0f;

                            var num25 = Main.myPlayer;
                            //Main.player[num25].lifeRegen += HPRegen;
                            Main.player[num25].lifeRegen += 9999;
                            Main.NewText($"MR. ELECTRIC PUT THIS *fella* IN THE PENIS EXPLOSION CHAMBER.");

                            AddHealthToTeamPlayers();
                        }
                    }
                }
            }

            if (JenSaneFourPoint.MegaMassHealKey.JustPressed)
            {
                if (this.MedBagEquipped)
                {
                    if (this.MassMaxHealAccessoryEquipped)
                    {
                        if (Potency >= 999)
                        {
                            Potency -= 6000;
                            Player.statLife += 9999;
                            var num25 = Main.myPlayer;
                            Main.player[num25].statLife += 9999;
                        }
                    }
                }
            }

            if (this.NecroMark) //Mark of the Necromancer, put all item abilities into this one but make them cheaper!
            {
                if (this.MedBagEquipped)
                {
                    if (Potency < PotencyMax)
                    {
                        if (Main.rand.Next(10) == 1)
                        {
                            Potency += 1;
                        }
                    }

                    if (JenSaneFourPoint.MegaMassHealKey.JustPressed) //Better death token
                    {
                            if (Potency >= 999)
                            {
                                Potency -= 3000;
                                Player.statLife += 9999;
                                var num25 = Main.myPlayer;
                                Main.player[num25].statLife += 9999;
                            }
                    }


                    if (JenSaneFourPoint.TeamRegenVer2.Current) //Skullen heart ability
                    {
                            if (Potency >= 10)
                            {
                                    Player.lifeRegen += HPRegen;
                                    Player.controlUseItem = false;
                                    Potency -= 3;
                                    Player.GetDamage(DamageClass.Generic) -= 0.25f;
                                    Player.moveSpeed -= 0.65f;

                                    var num25 = Main.myPlayer;
                                    Main.player[num25].lifeRegen += HPRegen;
                        }
                    }
                    

                    if (JenSaneFourPoint.ReviveTeam.JustPressed) //Revive entire team
                    { 
                //            if (Potency >= 998)
                  //          {
                            Potency -= 4000;
                            Player.respawnTimer = 0;
                            var num25 = Main.myPlayer;
                            Main.player[num25].respawnTimer = 0;
                    //           }
                    }


                    if (JenSaneFourPoint.CloseHeal.Current) //Heal closest player very fast
                    {
                        if (Potency >= 10)
                        {
                                Player.controlUseItem = false;
                                Potency -= 2;
                                Player.GetDamage(DamageClass.Generic) -= 0.95f;
                                Player.moveSpeed -= 1.0f;

                                var num25 = Main.myPlayer;

                                //TargetClosest   Player nearestPlayer = Main.player[Player.FindClosest(Vector2 location, 20, 20)];
                                Player closestPlayer = Main.player[Player.FindClosest(Player.Center, Main.player[num25].width, Main.player[num25].height)];

                                //       closestPlayer.lifeRegen += HPRegen * 2;
                                closestPlayer.lifeRegen += HPRegen * 2;
                        }
                    }




                }
            }

            if (this.MedBagEquipped) //skullen heart buffed
            {
                if (this.SkullHeartRegenIncrease)
                {
                    HPRegen += 35;
                }
            }

            if (this.MedBagEquipped) //Potency regeneration potion
            {
                if (this.PlagueRegenPotion)
                {
                    if (Potency >= 100)
                    {
                        if (Potency < PotencyMax)
                        {
                            if (Main.rand.Next(10) == 1)
                            {
                                Potency += 1;
                            }
                        }
                    }
                }
            }

  /*          if (JenSaneFourPoint.TeamRegenVer2.Current) //SkullenHeart
            {
                if (this.MedBagEquipped)
                {
                    if (Potency >= 10)
                    {
                        //if (CloakAccessoryEquipped = true)
                        if (this.CloakAccessoryEquipped)
                        //if (this.MedBagEquipped)
                        {
                            //var player2 = Main.player[Main.myPlayer];


                            //int p = Player.FindClosest(Player.Center, 0, 0);

                            Player.controlUseItem = false;
                            Potency -= 4;
                     //       Player.lifeRegen += HPRegen;
                            Player.GetDamage(DamageClass.Generic) -= 0.75f;
                            Player.moveSpeed -= 1.0f;
                            // Player.AddBuff(ModContent.BuffType<Buffs.Plague>(), 600, true);


                        //                   SkullUpdate();
                          //  UpdateSkuHea();
                            //     disfoostupidongod = true;



                            //    Player.AddBuff(ModContent.BuffType<Buffs.Plague>(), 500, true);


                            //    }

                        }
                    }
                }
            } */

            if (JenSaneFourPoint.TeamRegenVer2.Current) //WeDontLikeThomas
            {
                        if (this.WeDontLikeThomas)
                        {
                            Player.lifeRegen -= 55;

                            var Player2 = Main.player[Main.myPlayer];
                            if (Player != Player2 && Player.miscCounter % 10 == 0)
                            {
                                if (Player2.team == Player.team && Player.team != 0)
                                {
                                    var local = Player.position.X - Player2.position.X;
                                    var distance = (float)(Player.position.Y - Player2.position.Y);
                            Player2.lifeRegen -= 55;
                        }
                    }
                }
            }


            if (this.MedBagEquipped) //Normal med bag potency regen
            {
   //             int life = npc.life;
   //             npc.StrikeNPCNoInteraction(life, 0f, -npc.direction, true);

                if (Potency >= 100)
                {
                    if (Potency < PotencyMax)
                    {
                        if (Main.rand.Next(16) == 1)
                        {
                            Potency += 1;
                        }
                    }
                }
                else
                {
                    Player.moveSpeed -= 0.5f;
                    if (Main.rand.Next(20) == 1)
                    {
                        Potency += 1;
                    }
                }
            }

            if (this.MedBagEquipped) //Faster potency regen if not moving
            {
                if (Potency < PotencyMax)
                {
                    if (Player.velocity.X == 0)
                    {
                        if (Main.rand.Next(14) == 1)
                        {
                            Potency += 1;
                        }
                    }
                }
            }

            if (this.MedBagEquipped) //Potency Charm
            {
                if (PlagueRegenItemEquipped = true)
                {
                    Player.GetDamage(DamageClass.Generic) -= 0.75f;
                    Player.GetDamage(ModContent.GetInstance<PlagueDoctorDamageClass>()) += 0.75f;

                    if (Potency < PotencyMax)
                    {
                        if (Main.rand.Next(16) == 1)
                        {
                            Potency += 1;
                        }
                    }
                }
            }

            if (this.MedBagEquipped) //Fractured Moon Lord Heart REMOVE THE 100 THING
            {
                if (PlagueRegenMoonLordEquipped = true)
                {
                    HPRegen = +35;
                    Player.GetDamage(ModContent.GetInstance<PlagueDoctorDamageClass>()) += 0.35f;

                    if (Potency < PotencyMax)
                    {
                        if (Main.rand.Next(15) == 1)
                        {
                            Potency += 1;
                        }
                    }
                }
            }

            if (this.MedBagEquipped) //Urine o milk god
            {
                if (LesserPlagueRegenItemEquipped = true)
                {
                    if (Potency < PotencyMax)
                    {
                        if (Main.rand.Next(16) == 1)
                        {
                            Potency += 1;
                        }
                    }
                }
            }



            //healing bag team regen
            if (this.MedBagEquipped)
            {
                Player.lifeRegen += 1;
                var Player2 = Main.player[Main.myPlayer];
                if (Player != Player2 && Player.miscCounter % 10 == 0)
                {
                    if (Player2.team == Player.team && Player.team != 0)
                    {
                        var local = Player.position.X - Player2.position.X;
                        var distance = (float)(Player.position.Y - Player2.position.Y);
                        if (Math.Sqrt(local * local + (double)distance * (double)distance) < 800.0)
                        {
                            // player2.AddBuff(43, 20, true);
                            Player2.lifeRegen += 2;
                        }
                    }
                }
            }


            if (this.MedBagEquipped) //Plague Set
            {
                if (Potency < PotencyMax)
                {
                    {
                        if (this.PlagueSet1Equipped)
                        {
                            if (MedBagEquipped = true)
                            {
                                if (Main.rand.Next(20) == 1)
                                {
                                    Potency += 1;
                                }
                                Player.GetDamage(ModContent.GetInstance<PlagueDoctorDamageClass>()) += 0.45f;
                                Player.GetDamage(DamageClass.Generic) -= 0.3f;

                            }
                            Player.setBonus += Player.GetDamage(ModContent.GetInstance<PlagueDoctorDamageClass>()) += 0.25f;
                        }
                    }

                    if (this.MedBagEquipped)
                    {
                        if (this.PlagueSet2Equipped)
                        {
                            if (MedBagEquipped = true)
                            {
                                if (Main.rand.Next(20) == 1)
                                {
                                    Potency += 1;
                                }
                            }
                            Player.GetDamage(ModContent.GetInstance<PlagueDoctorDamageClass>()) += 0.25f;
                        }
                    }

                    if (this.MedBagEquipped)
                    {
                        if (this.PlagueSet3Equipped)
                        {
                            if (MedBagEquipped = true)
                            {
                                if (Main.rand.Next(20) == 1)
                                {
                                    Potency += 1;
                                }
                            }
                            Player.GetDamage(ModContent.GetInstance<PlagueDoctorDamageClass>()) += 0.25f;
                        }
                    }
                }

            }

            if (this.MedBagEquipped) //Post moon lord plague set
            {
                if (Potency < PotencyMax)
                {
                    {
                        if (this.MLPlagueSet1Equipped)
                        {
                            if (MedBagEquipped = true)
                            {
                                if (Main.rand.Next(10) == 1)
                                {
                                    Potency += 1;
                                }
                                Player.GetDamage(ModContent.GetInstance<PlagueDoctorDamageClass>()) += 0.95f;
                                Player.GetDamage(DamageClass.Generic) -= 0.3f;

                            }
                            Player.setBonus += Player.GetDamage(ModContent.GetInstance<PlagueDoctorDamageClass>()) += 1.25f;
                        }
                    }

                    if (this.MedBagEquipped)
                    {
                        if (this.MLPlagueSet2Equipped)
                        {
                            if (MedBagEquipped = true)
                            {
                                if (Main.rand.Next(10) == 1)
                                {
                                    Potency += 1;
                                }
                            }
                            Player.GetDamage(ModContent.GetInstance<PlagueDoctorDamageClass>()) += 0.75f;
                        }
                    }

                    if (this.MedBagEquipped)
                    {
                        if (this.MLPlagueSet3Equipped)
                        {
                            if (MedBagEquipped = true)
                            {
                                if (Main.rand.Next(10) == 1)
                                {
                                    Potency += 1;
                                }
                            }
                            Player.GetDamage(ModContent.GetInstance<PlagueDoctorDamageClass>()) += 0.75f;
                        }
                    }
                }
            }

                if (this.MedBagEquipped) //Mushroom Set
            {
                if (Potency < PotencyMax)
                {
                    {
                        if (this.MushroomSet1Equipped)
                        {
                            if (MedBagEquipped = true)
                            {
                                if (Main.rand.Next(23) == 1)
                                {
                                    Potency += 1;
                                }
                                Player.GetDamage(ModContent.GetInstance<PlagueDoctorDamageClass>()) += 0.1f;

                            }
                            Player.setBonus += Player.GetDamage(ModContent.GetInstance<PlagueDoctorDamageClass>()) += 0.1f;
                        }
                    }

                    if (this.MedBagEquipped)
                    {
                        if (this.MushroomSet2Equipped)
                        {
                            if (MedBagEquipped = true)
                            {
                                if (Main.rand.Next(23) == 1)
                                {
                                    Potency += 1;
                                }
                            }
                            Player.GetDamage(ModContent.GetInstance<PlagueDoctorDamageClass>()) += 0.1f;
                        }
                    }

                    if (this.MedBagEquipped)
                    {
                        if (this.MushroomSet3Equipped)
                        {
                            if (MedBagEquipped = true)
                            {
                                if (Main.rand.Next(23) == 1)
                                {
                                    Potency += 1;
                                }
                            }
                            Player.GetDamage(ModContent.GetInstance<PlagueDoctorDamageClass>()) += 0.1f;
                        }
                    }
                }

            }

            if (this.SpawnThomas)
            {

               // return true;
            }

        }

        public override void OnHitNPCWithItem(Item item, NPC target, NPC.HitInfo hit, int damageDone)/* tModPorter If you don't need the Item, consider using OnHitNPC instead */ //Put this in example player and check if player has the buff and if they do then activate the code
        {
            if (PlagueCause = true)
            {
                if (Main.rand.Next(2) == 1)
                {
          //replace with hostile plague later          target.AddBuff(BuffID.Poisoned, 30);
                }
            }
        }//MurderedThomas

        public override void SaveData(TagCompound tag)
        {
            var playerData = new List<string>();
            //    if (InsaneMode) playerData.Add("InsaneMode");
            if (FreedSoul) playerData.Add("FreedSoul");
            tag.Add($"{Mod.Name}.{Player.name}.Data", playerData);
        }

        public override void LoadData(TagCompound tag)
        {
            var playerData = tag.GetList<string>($"{Mod.Name}.{Player.name}.Data");
            FreedSoul = playerData.Contains("FreedSoul");
        //    MurderedThomas = playerData.Contains("MurderedThomas");
            // InsaneMode = playerData.Contains("InsaneMode");

            //   disabledToggles = tag.GetList<string>($"{Mod.Name}.{Player.name}.TogglesOff");
        }


        public void AddHealthToTeamPlayers(int healthToAdd)
        {
            // Player sourcePlayer = Main.player[sourcePlayerIndex];
            int healthToAdd 100
            // sourcePlayerIndex

            Player sourcePlayer = Main.player[i];

            for (int i = 0; i < Main.maxPlayers; i++)
            {
                Player targetPlayer = Main.player[i];

                // Check if the target player is on the same team as the source player
                if (targetPlayer.active && targetPlayer.team == sourcePlayer.team)
                {
                    // Add health to the target player
                    targetPlayer.statLife += healthToAdd;

                    // Ensure that the player's current health doesn't exceed their maximum health
                    if (targetPlayer.statLife > targetPlayer.statLifeMax)
                    {
                        targetPlayer.statLife = targetPlayer.statLifeMax;
                    }
                }
            }
        }
    



    }

}