using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.DataStructures;
using Terraria.ModLoader;

namespace JenSaneFourPoint.Items
{
	public class ppTickler : ModItem
	{

        public int PotencyCost = 10;
       // public int PotencyCost = 5;
        public int PotencyChance = 100;

        public override void SetDefaults()
        {
            Item.width = 32;
            Item.height = 32;
            Item.value = Item.buyPrice(0, 10, 0, 0);
            Item.rare = 9;
            Item.expert = true;
            Item.accessory = true;
            Item.defense = 6;
        }

        public override void UpdateAccessory(Player player, bool hideVisual)
        {
            const float distance = 300f;

            for (int i = 0; i < Main.maxPlayers; i++)
                if (Main.player[i].active && !Main.player[i].dead && i != player.whoAmI && Main.player[i].Distance(player.Center) < distance)
                    //Main.player[i].AddBuff(ModContent.BuffType<Plague>(), 2);
                    Main.player[i].AddBuff(Mod.Find<ModBuff>("pp").Type, 2);
        }

    }
}