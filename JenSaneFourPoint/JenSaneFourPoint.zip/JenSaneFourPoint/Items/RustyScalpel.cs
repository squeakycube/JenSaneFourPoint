using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.DataStructures;
using Terraria.ModLoader;

namespace JenSaneFourPoint.Items
{
    public class RustyScalpel : ModItem
    {

        public int PotencyCost = 10;
        // public int PotencyCost = 5;
        public int PotencyChance = 100;

        public override void SetStaticDefaults()
        {
            // Tooltip.SetDefault("Heals the nearest player but drains your health while pressing N. Requires potency.");
            // Tooltip.SetDefault("Increases health regeneration for teammates if N key is pressed and held, but it renders you immobile. Heals entire team to max when P is pressed. Revives all currently dead players with Y. Boosts potency regeneration. All abilities cost less potency than on previous accessories.");
        }

        public override void SetDefaults()
        {
            Item.width = 22;
            Item.height = 24;
            Item.value = Item.buyPrice(silver: 150);
            Item.rare = 3;
            Item.accessory = true;
            Item.defense = 6;
        }

        public override void UpdateAccessory(Player player, bool hideVisual)
        {
            PlagueReal p = player.GetModPlayer<PlagueReal>();
            p.Scalpel = true;
        }

    }
}