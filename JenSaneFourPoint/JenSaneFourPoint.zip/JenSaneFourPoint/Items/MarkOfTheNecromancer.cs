﻿using System.Linq;
using Terraria;
using Terraria.DataStructures;
using Terraria.GameContent.Creative;
using Terraria.ID;
using Terraria.ModLoader;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using Terraria.DataStructures;
using Terraria.GameContent;
using Terraria.ID;
using Terraria.Localization;
using Terraria.Map;

namespace JenSaneFourPoint.Items
{
	public class MarkOfTheNecromancer : ModItem
	{
		public override void SetDefaults() {
			Item.width = 30;
			Item.height = 32;
			Item.accessory = true;
			Item.value = Item.sellPrice(gold: 1000);
			Item.rare = ItemRarityID.Master;
		}

        public override void SetStaticDefaults() {
            // Tooltip.SetDefault("\nIncreases health regeneration for teammates if N key is pressed and held, but it renders you immobile.\nHeals entire team to max when P is pressed.\nRevives all currently dead players with Y.\nPress L to heal the nearest player rapidly.\nBoosts potency regeneration and makes all abilities cost less.");
           // Tooltip.SetDefault("Increases health regeneration for teammates if N key is pressed and held, but it renders you immobile. Heals entire team to max when P is pressed. Revives all currently dead players with Y. Boosts potency regeneration. All abilities cost less potency than on previous accessories.");
		}



        public override void UpdateAccessory(Player player, bool hideVisual)
        {
            PlagueReal p = player.GetModPlayer<PlagueReal>();
            p.NecroMark = true;
        }

        public override void AddRecipes()
        {
            Recipe recipe = CreateRecipe();
            recipe.AddIngredient(Mod, "RustyScalpel", 1);
            recipe.AddIngredient(Mod, "SkullenHeart", 1);
            recipe.AddIngredient(Mod, "DeathToken", 1);
            recipe.AddIngredient(Mod, "SoulOfBlight", 15);
            recipe.AddTile(TileID.Anvils);
            recipe.Register();
        }
    }
}
