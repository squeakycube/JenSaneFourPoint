using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using Terraria.ModLoader.Utilities;
using Terraria.GameContent.ItemDropRules;

namespace JenSaneFourPoint.NPCs
{
	// Party Zombie is a pretty basic clone of a vanilla NPC. To learn how to further adapt vanilla NPC behaviors, see https://github.com/tModLoader/tModLoader/wiki/Advanced-Vanilla-Code-Adaption#example-npc-npc-clone-with-modified-projectile-hoplite
	public class Alice : ModNPC
	{
		public override void SetStaticDefaults() {
			// DisplayName.SetDefault("Alice's Enemy");
        //    Main.npcFrameCount[NPC.type] = Main.npcFrameCount[1];
        }

		public override void SetDefaults() {
			NPC.width = 72;
			NPC.height = 40;
			NPC.damage = 45;
			NPC.defense = 6;
			NPC.lifeMax = 20000;
			NPC.value = 60f;
			NPC.knockBackResist = 0.5f;
			NPC.aiStyle = 17;
		}

        public override float SpawnChance(NPCSpawnInfo spawnInfo)
        {
            if (NPC.downedMechBossAny)
            {
                return SpawnCondition.OverworldNightMonster.Chance * 0.02f;
            }
            else
            {
                return 0.0f;
            }
        }

        public override void ModifyNPCLoot(NPCLoot npcLoot) {
			npcLoot.Add(ItemDropRule.Common(Mod.Find<ModItem>("CrowSkull").Type, 5));
            npcLoot.Add(ItemDropRule.Common(Mod.Find<ModItem>("ExampleWings").Type, 500));
            npcLoot.Add(ItemDropRule.Common(Mod.Find<ModItem>("PupuyoukaiSummon").Type, 50));
        }
    }
}