using Microsoft.Xna.Framework;
using System;
using Terraria;
using Terraria.ModLoader;

namespace JenSaneFourPoint.Buffs
{
    public class pp : ModBuff
    {



        public override void SetStaticDefaults()
        {
            // DisplayName.SetDefault("pp");
            // Description.SetDefault(@"""pp""");
            Main.debuff[Type] = true;
            Main.pvpBuff[Type] = true;
            Main.buffNoSave[Type] = true; // Causes this buff not to persist when exiting and rejoining the world
           // BuffID.Sets.LongerExpertDebuff[Type] = true; // If this buff is a debuff, setting this to true will make this buff last twice as long on players in expert mode

        }

        // int lifeSteal = damage / 10;



        public override void Update(Player player, ref int buffIndex)
        {





                const float distance = 300f;
            for (int i = 0; i < Main.maxPlayers; i++)
                if (Main.player[i].active && !Main.player[i].dead && i != player.whoAmI && Main.player[i].Distance(player.Center) < distance)
                    Main.player[i].AddBuff(Mod.Find<ModBuff>("Plague").Type, 2);

            for (int i = 0; i < 20; i++)
            {
                Vector2 offset = new Vector2();
                double angle = Main.rand.NextDouble() * 2d * Math.PI;
                offset.X += (float)(Math.Sin(angle) * distance);
                offset.Y += (float)(Math.Cos(angle) * distance);
                Dust dust = Main.dust[Dust.NewDust(player.Center + offset - new Vector2(4, 4), 0, 0, 119, 0, 0, 100, Color.White, 1f)];
                dust.velocity = player.velocity;
                if (Main.rand.NextBool(3))
                    dust.velocity += Vector2.Normalize(offset) * -5f;
                dust.noGravity = true;
            }

        }
    }
}