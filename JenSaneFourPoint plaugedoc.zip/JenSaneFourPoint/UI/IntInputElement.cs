
//            TextDisplayFunction = () => Index + 1 + ": " + IntList[Index];
//
  //          UIPanel textBoxBackground = new UIPanel();
    //        textBoxBackground.SetPadding(0);
      //      UIFocusInputTextField uIInputTextField = new UIFocusInputTextField("Type here");
        //    textBoxBackground.Top.Set(0f, 0f);
          //  textBoxBackground.Left.Set(-190, 1f);
//            textBoxBackground.Width.Set(180, 0f);
  //          textBoxBackground.Height.Set(30, 0f);
    //        Append(textBoxBackground);
    
         //   uIInputTextField.SetText(GetValue().ToString());
    //        uIInputTextField.Top.Set(5, 0f);
      //      uIInputTextField.Left.Set(10, 0f);
        //    uIInputTextField.Width.Set(-42, 1f); // allow space for arrows
          //  uIInputTextField.Height.Set(20, 0);
                

//        protected virtual int GetValue() => (int)GetObject();

  //      protected virtual void SetValue(int value) => SetObject(Utils.Clamp(value, Min, Max)); 