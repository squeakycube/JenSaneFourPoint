using Terraria.GameContent.UI;
using Terraria.ModLoader;

namespace JenSaneFourPoint.Currencies
{
	public class JenSaneFourPoint : Mod
    {
        public static int ExampleCustomCurrencyId;

        public override void Load()
        {
            ExampleCustomCurrencyId = CustomCurrencyManager.RegisterCurrency(new Currencies.LotharUpgradeCurrency(ModContent.ItemType<Items.StardustTrident>(), 999L, "Mods.JenSaneFourPoint.Currencies.LotharUpgradeCurrency"));
            // Add certain equip textures
            //EquipLoader.AddEquipTexture(this, "JenSaneFourPoint/Items/MilkRobes_Legs", EquipType.Legs, name: "MilkRobes_Legs");
            //EquipLoader.AddEquipTexture(this, "JenSaneFourPoint/Items/MilkRobes_Legs", EquipType.Legs, name: "MilkRobes_Legs");
            //AddEquipTexture(new Items.Armor.BlockyHead(), null, EquipType.Head, "BlockyHead", "ExampleMod/Items/Armor/ExampleCostume_Head");
            //AddEquipTexture(new Items.Armor.BlockyBody(), null, EquipType.Body, "BlockyBody", "ExampleMod/Items/Armor/ExampleCostume_Body", "ExampleMod/Items/Armor/ExampleCostume_Arms");
            //AddEquipTexture(new Items.Armor.BlockyLegs(), null, EquipType.Legs, "BlockyLeg", "ExampleMod/Items/Armor/ExampleCostume_Legs");
        }

    }
}